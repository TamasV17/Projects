﻿using System;

namespace Jegykiadás
{
    class Program
    {
        static Random RND = new Random();
        static void Main(string[] args)
        {
            LancoltLista[] utasok = new LancoltLista[50];
            for (int i = 0; i < utasok.Length; i++)
            {
                utasok[i].JegyVasarlas += Vasarlas;
                utasok[i].UtasTorles += Torles;
            }
        }
        static void Vasarlas(Utas utas)
        {
            Console.WriteLine($"[INFO] Vonatjegyvásárlás történt! Név: {utas.Neve}, {utas.Hely}.hely , Úticél: {utas.Uticel}.");
        }
        static void Torles(Utas utas)
        {
            Console.WriteLine($"[INFO] Utastörlés történt! Név: {utas.Neve}, {utas.Hely}.hely, Úticél: {utas.Uticel}.");
        }


        public static JegyTipus GenerateJegyTipus()
        {
            switch (RND.Next(0,3))
            {
                case 0: return JegyTipus.masodosztaly;
                case 1: return JegyTipus.elsoosztaly;
                default: return JegyTipus.biznisz;                 
            }
        }
        public static string GenerateName()
        {
            string FirstName = "";
            string LastName = "";
           
            string[] lastNames = new string[10] { "Kovács", "Varga", "Kolompár", "Rézműves", "Kerekes", "Tóth", "Kosár", "Arany", "Rácz", "Juhász" };
            string[] FfemaleNames = new string[4] { "Dóra", "Virág", "Adél", "Cintia"};
            string[] FmaleNames = new string[5] {"János", "Ödön", "István", "Gergely", "Áron"};

            if (RND.Next(1, 2) == 1)
            {
                FirstName = FmaleNames[RND.Next(0, FmaleNames.Length - 1)];
                LastName = lastNames[RND.Next(0, lastNames.Length - 1)];
            }
            else
            {
                FirstName = FfemaleNames[RND.Next(0, FfemaleNames.Length - 1)];
                LastName = lastNames[RND.Next(0, lastNames.Length - 1)];
            }
            string compNAME = LastName + FirstName;
            return compNAME;
        }
        public static Utas UtasGenerator(string uticel, string neve, int helye, JegyTipus tipus)
        {
            
        }
        public static Utas UtasCreator()
        {
            Utas utas = null;
            while (utas == null)
            {
                utas = new Utas(uticel, GenerateName(), helye, GenerateJegyTipus());
            }
            return utas;
        }
    }
}
