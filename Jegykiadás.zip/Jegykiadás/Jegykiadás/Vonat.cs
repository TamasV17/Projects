﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Jegykiadás
{
    class Vonat
    {
        public Vonat(string nev, int ferohely)
        {
            Nev = nev;
            Ferohely = ferohely;
        }
        public string Nev { get; set; }
        public int Ferohely { get; set; }
        public override int GetHashCode()
        {
            return Nev.GetHashCode() ^ Ferohely.GetHashCode();
        }
        public override bool Equals(object obj)
        {
            if ((obj as Vonat).Nev == this.Nev && (obj as Vonat).Ferohely == this.Ferohely)
            {
                return true;
            }
            return false;
        }
    }
}
