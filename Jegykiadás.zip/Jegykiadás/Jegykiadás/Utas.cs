﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Jegykiadás
{
    class Utas : IJegy
    {
        public Utas(string uticel,string neve, int hely, JegyTipus jegytipus)
        {
            Uticel = uticel;
            this.Neve = neve;
            Hely = hely;
            int lenght = Uticel.Length;
            Ar = lenght*Hely;
            switch (jegytipus)
            {
                case JegyTipus.masodosztaly: 
                    Hely = 1;
                    break;
                case JegyTipus.elsoosztaly:
                    Hely = 3;
                    break;
                case JegyTipus.biznisz:
                    Hely = 6;
                    break;
            }
        }

        public int Hely { get ; set ; }
        public int Ar { get ; set ; }
        public string Uticel { get; set; }
        public string Neve { get; set; }
        JegyTipus IJegy.Tipus { get ; set ; }
       
    }
}
